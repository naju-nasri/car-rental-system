# MEAN-Stack-Based-Car-Rental-Web-Application
A web application developed to increase the sales of the car rental stores through online booking system and it also helps the managers to analyze monthly car rental sales through bar graph representation.
###Main Technologies used are
> Angular2<br/>
> Node.js<br/>
> Express<br/>
> MongoDB<br/>
> Sass<br/>
> Gulp<br/>
> HTML5<br/>
> CSS3<br/>
> Bootstrap 3
